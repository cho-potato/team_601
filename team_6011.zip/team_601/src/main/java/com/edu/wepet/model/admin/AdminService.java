package com.edu.wepet.model.admin;

import com.edu.wepet.domain.Admin;

public interface AdminService {
	
	public Admin select(Admin admin);

}
