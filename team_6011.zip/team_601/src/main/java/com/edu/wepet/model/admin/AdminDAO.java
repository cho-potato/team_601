package com.edu.wepet.model.admin;

import com.edu.wepet.domain.Admin;

public interface AdminDAO {

	public Admin select(Admin admin);
	
	
}
