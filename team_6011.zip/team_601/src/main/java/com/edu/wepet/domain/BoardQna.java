package com.edu.wepet.domain;

public class BoardQna {

}
