package com.edu.wepet.domain;

import lombok.Data;

@Data
public class Sns {
	
	private int sns_idx;
	private String sns_type;
	

}
