package com.edu.wepet.domain;

public class PetSitter {

	 private int petsitter_idx;
	 
	 private Member member; 		//fk-- 일반회원
	 private SitterApply sitterApply; 		//fk-- 인증구분(펫시터)
	 
	 private 
	 
	 
	 
}
