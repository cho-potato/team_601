package com.edu.wepet.domain;

public class SitterApply {
	private int sitter_apply_idx;
	private int apply_ox; 		// 0 이면 인증성공, 1 이면 인증실패, 2: 인증보류
 	
}
