package com.edu.wepet.domain;

import lombok.Data;

@Data
public class Admin {

	private int admin_idx;
	private String admin_id;
	private String admin_pass;
	
}
