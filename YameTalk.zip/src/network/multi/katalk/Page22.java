package network.multi.katalk;

import java.awt.Dimension;

import javax.swing.JPanel;

public class Page22 extends JPanel{
	ClientMain22 clientMain22;
	
	public Page22(ClientMain22 clientMain22) {
		this.clientMain22 = clientMain22;
		
		this.setPreferredSize(new Dimension(520,600));
	}
}
