package network.multi.katalk;

// dto
public class ChatMember22 {
	private int chatMember_idx;
	private String id;
	private String pass;
	private String name;
	
	public int getChatMember_idx() {
		return chatMember_idx;
	}
	public void setChatMember_idx(int chatMember_idx) {
		this.chatMember_idx = chatMember_idx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
